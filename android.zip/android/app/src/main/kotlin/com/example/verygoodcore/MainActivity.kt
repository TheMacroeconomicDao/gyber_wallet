package com.example.verygoodcore.crypto_wallet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
